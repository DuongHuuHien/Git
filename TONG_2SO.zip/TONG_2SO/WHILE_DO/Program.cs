﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using x = System.Console;
namespace WHILE_DO
{
    class Program
    {
        static void Main(string[] args)
        {
            // khia bao khoi tao
		int i=1;
        int j;
		//xuat ra 
		while(i<=10){
			x.WriteLine("i={0}",i);
            x.ReadLine();
			i++;
        }
        //do
        //{
        //    x.WriteLine("j={1}", j);
        //    x.ReadLine();


        //    j++;
        //} while (j <= 10);
        
    }
    }
}
